DANAYA SERVICES DS — projet Android Studio
=========================================

Ce dossier est un PROJET SOURCE Android, pas un APK déjà compilé.

Contenu :
- Application Android native simple qui ouvre le prototype dans une WebView.
- Logo fourni intégré aux ressources web.
- Bouton de contact WhatsApp configuré vers +223 77 01 87 04.
- Catalogue et fonctionnalités locales du prototype.

Pour générer un APK :
1. Installer Android Studio sur un ordinateur.
2. Ouvrir le dossier DanayaServicesDS_AndroidStudio dans Android Studio.
3. Accepter l'installation des composants SDK demandés.
4. Attendre la synchronisation Gradle.
5. Choisir Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio produira un APK de test.

Limites importantes :
- Ce projet n'est PAS un clone complet de WhatsApp Business.
- Il ne fournit pas de messagerie multi-utilisateurs, d'appels audio/vidéo, de statuts synchronisés ni de notifications serveur.
- Les commandes ouvrent WhatsApp avec un message prérempli; le client doit appuyer sur Envoyer.
- Les données du prototype sont principalement conservées localement sur le téléphone.
- Les messages automatiques envoyés sans intervention nécessitent la plateforme officielle WhatsApp Business, un compte Meta Business et un serveur.

Identifiant Android : com.danayaservices.ds
Nom affiché : DANAYA SERVICES DS
Contact WhatsApp : +223 77 01 87 04
